import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Scanner i = new Scanner(System.in);
        System.out.println("Введите числа a и b через пробел");
        int a = i.nextInt(), b = i.nextInt();
        if (a < b) {
            System.out.println("a < b");
        } else if (a > b) {
            System.out.println("a > b");
        } else {
            System.out.println("a = b");
        }
        System.out.print("a + b = ");
        System.out.println(a+b);
        System.out.print("a - b = ");
        System.out.println(a-b);
        System.out.print("a * b = ");
        System.out.println(a*b);
        if (b==0) {System.out.println("Division by zero");} else
        {System.out.print("a / b = ");
        System.out.println(a/b);}
    }
}